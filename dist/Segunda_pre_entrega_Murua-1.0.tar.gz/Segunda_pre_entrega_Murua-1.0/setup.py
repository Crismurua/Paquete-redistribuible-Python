from setuptools import setup

setup(
    name='Segunda_pre_entrega_Murua',
    version='1.0',
    description='Segunda entrega - Paquete redistribuible clase Cliente',
    author='Cristian Murua',
    author_email='cristianmurua1995@gmail.com',
    packages=['Segunda_pre_entrega_Murua'],
)